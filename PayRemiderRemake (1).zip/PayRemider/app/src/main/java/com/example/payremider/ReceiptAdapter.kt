package com.example.payremider

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import java.text.NumberFormat
import java.util.Locale

class ReceiptAdapter(
    private var receipts: List<Receipt>,
    private val onItemClick: (Receipt) -> Unit,
    private val onDeleteClick: (Receipt) -> Unit  // NUEVO: callback para eliminar
) : RecyclerView.Adapter<ReceiptAdapter.ReceiptViewHolder>() {

    class ReceiptViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvAmount: TextView = itemView.findViewById(R.id.tvAmount)
        private val tvDate: TextView = itemView.findViewById(R.id.tvDate)
        private val tvDescription: TextView = itemView.findViewById(R.id.tvDescription)
        private val tvCategory: TextView = itemView.findViewById(R.id.tvCategory)
        private val btnDelete: ImageButton = itemView.findViewById(R.id.btnDelete)
        private val cardReceipt: CardView = itemView.findViewById(R.id.cardReceipt)

        fun bind(receipt: Receipt, onItemClick: (Receipt) -> Unit, onDeleteClick: (Receipt) -> Unit) {
            val format = NumberFormat.getCurrencyInstance(Locale("es", "MX"))
            tvAmount.text = format.format(receipt.amount)

            // 🔴 FORMATEAR FECHA correctamente
            tvDate.text = formatearFecha(receipt.date)

            tvDescription.text = receipt.description.ifEmpty { "Sin descripción" }

            // Mostrar primera letra de la categoría
            tvCategory.text = receipt.category.take(1)

            // Cambiar color según categoría
            val color = when (receipt.category) {
                "Comida" -> "#4CAF50"      // Verde
                "Transporte" -> "#2196F3"   // Azul
                "Servicios" -> "#FF9800"    // Naranja
                "Entretenimiento" -> "#9C27B0" // Púrpura
                "Salud" -> "#F44336"        // Rojo
                else -> "#3A86FF"            // Azul claro
            }
            tvCategory.setBackgroundColor(android.graphics.Color.parseColor(color))

            cardReceipt.setOnClickListener {
                onItemClick(receipt)
            }

            btnDelete.setOnClickListener {
                onDeleteClick(receipt)
            }
        }

        // 🔴 FUNCIÓN PARA FORMATEAR FECHA
        private fun formatearFecha(fecha: String): String {
            // Si viene como "23042006" convertir a "23/04/2006"
            if (fecha.length == 8 && fecha.all { it.isDigit() }) {
                val dia = fecha.substring(0, 2)
                val mes = fecha.substring(2, 4)
                val anio = fecha.substring(4, 8)
                return "$dia/$mes/$anio"
            }
            // Si ya tiene formato, devolver igual
            return fecha
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ReceiptViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_receipt, parent, false)
        return ReceiptViewHolder(view)
    }

    override fun onBindViewHolder(holder: ReceiptViewHolder, position: Int) {
        holder.bind(receipts[position], onItemClick, onDeleteClick)
    }

    override fun getItemCount(): Int = receipts.size

    fun updateList(newReceipts: List<Receipt>) {
        receipts = newReceipts
        notifyDataSetChanged()
    }
}