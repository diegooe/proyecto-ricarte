package com.example.payremider

data class Receipt(
    val id: Long = System.currentTimeMillis(),
    val amount: Double,
    val date: String,
    val description: String,
    val category: String
)