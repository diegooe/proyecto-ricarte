package com.example.payremider

import android.content.Intent
import android.os.Bundle
import android.view.animation.AnimationUtils
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class HomeActivity : AppCompatActivity() {

    private lateinit var tvNombreUsuario: TextView
    private lateinit var tvTotalPendiente: TextView
    private lateinit var tvCantidadPagos: TextView
    private lateinit var fabAgregarPago: FloatingActionButton
    private lateinit var bottomNav: BottomNavigationView
    private lateinit var ivAvatar: android.widget.ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        initViews()
        cargarDatosUsuario()
        animarEntrada()
        setupBottomNav()
        setupFab()
        setupAvatar()
        setupOnBackPressed()
    }

    private fun initViews() {
        tvNombreUsuario  = findViewById(R.id.tvNombreUsuario)
        tvTotalPendiente = findViewById(R.id.tvTotalPendiente)
        tvCantidadPagos  = findViewById(R.id.tvCantidadPagos)
        fabAgregarPago   = findViewById(R.id.fabAgregarPago)
        bottomNav        = findViewById(R.id.bottomNav)
        ivAvatar         = findViewById(R.id.ivAvatar)
    }

    private fun cargarDatosUsuario() {
        // TODO: Backend reemplazará esto con Room + ViewModel
        val prefs  = getSharedPreferences("PayReminderPrefs", MODE_PRIVATE)
        val nombre = prefs.getString("userName", "Usuario") ?: "Usuario"
        tvNombreUsuario.text  = nombre
        tvTotalPendiente.text = "$0.00"
        tvCantidadPagos.text  = "0"
    }

    private fun animarEntrada() {
        tvTotalPendiente.startAnimation(
            AnimationUtils.loadAnimation(this, R.anim.fade_in_up)
        )
        tvCantidadPagos.startAnimation(
            AnimationUtils.loadAnimation(this, R.anim.fade_in_up).also { it.startOffset = 100 }
        )
        fabAgregarPago.startAnimation(
            AnimationUtils.loadAnimation(this, R.anim.scale_in)
        )
        bottomNav.startAnimation(
            AnimationUtils.loadAnimation(this, R.anim.fade_in_up).also { it.startOffset = 200 }
        )
    }

    private fun setupBottomNav() {
        bottomNav.selectedItemId = R.id.nav_home

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_home    -> true
                R.id.nav_agregar -> {
                    // TODO: navegar a AgregarPagoActivity cuando esté lista
                    true
                }
                R.id.nav_perfil  -> {
                    cerrarSesion()
                    true
                }
                else -> false
            }
        }
    }

    private fun setupFab() {
        fabAgregarPago.setOnClickListener {
            // TODO: navegar a AgregarPagoActivity cuando esté lista
        }
    }


    private fun setupAvatar() {
        ivAvatar.setOnClickListener {
            cerrarSesion()
        }
    }

    private fun cerrarSesion() {
        val prefs = getSharedPreferences("PayReminderPrefs", MODE_PRIVATE)
        prefs.edit().putBoolean("isLoggedIn", false).apply()

        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
        finishAffinity()
    }

    private fun setupOnBackPressed() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {

                moveTaskToBack(true)
            }
        })
    }
}